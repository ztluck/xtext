package org.eclipse.xtext.example.gmf.diagram.edit.helpers;

/**
 * @generated
 */
public class SimplePropertyEditHelper extends EntitiesBaseEditHelper {
}
